﻿安装请选择config-install.plist  安装完成后使用config.plist
安装请选择config-install.plist  安装完成后使用config.plist
安装请选择config-install.plist  安装完成后使用config.plist
安装请选择config-install.plist  安装完成后使用config.plist
安装请选择config-install.plist  安装完成后使用config.plist
(安装教程http://bbs.pcbeta.com/viewthread-1554404-1-1.html)
你需要关闭secure boot,花屏请关闭secure boot，还需要纯UEFI启动   不要用legacy support

请知晓如果你不会关闭secure boot  legacy support启动请放弃安装黑苹果吧

使用本EFI安装黑苹果过程中造成的任何硬件损坏，由你本人负责。

经历了几个beta版，终于迎来了Release Candidate版，所以或多多少有bug（本efi在10.12.5测试通过）
几个beta版反正也没有人反馈有什么bug，所以RC版   1.删除了多余的补丁，加入了lilu.kext和Shiki.kext 修复了itunes播放音乐视频黑屏的bug
										  2.开机小键盘默认打开
										  3.亮度开机默认0x0300
										  4.OsxAptioFixDrv-64.efi换成了修改版，解决了随机禁行的问题。
										  5.更换了的minStolenSize patch （https://www.tonymacx86.com/threads/guide-alternative-to-the-minstolensize-patch-with-32mb-dvmt-prealloc.221506/）
										  6.我的无线网卡已更换为BCM94352Z（联想白名单版），所以此引导里面包含BCM94352Z的补丁和驱动。
										  7.添加了NVME SM951 SSD驱动补丁  修复二次安装出现的不识别固态或者固态不显示了。
											修改config配置文件   更新到了clover4077版本
										  8.移除了ApplePS2SmartTouchPad.kext添加了VoodooPS2Controller.kext，
										  并且加入了关于联想FN键的设置(通过对比远景上传的ps2驱动得到的)亮度无法调节请去>统偏好设置>键盘>快捷键>显示器 自行修改




					update 1.2   根据lishuai123与rehabman指出删除了无用的变频文件ssdt，与patch for GPRW->XPRW。（详情见  #635  https://www.tonymacx86.com/threads/guide-hackrnvmefamily-co-existence-with-ionvmefamily-using-class-code-spoof.210316/page-64）

 
注：	1.未测试HDMI 不知道能不能启动
   	2.本人没有NVME固态，未测试nvme  请自行打补丁（https://github.com/RehabMan/patch-nvme）联想（最新bios已经原生支持nvme在bios可显示nvme固态）
   	3.在手动睡眠唤醒后可能会出现无声音。请拔掉电源再睡一次就好（自动睡眠后唤醒是不会	有问题的）
	4.笔记本键盘的FN键为静音键，为了更好的使用请BIOS关掉hotkey模式。
	5.安装10.12.5后用Kext Utility添加CodecCommander.kext驱动文件，即可修复耳机杂音
	6.恢复多档调光请看（https://www.tonymacx86.com/threads/guide-laptop-backlight-control-using-applebacklightinjector-kext.218222/）


             本efi根据群内蘭的EFI修改而来，我只是搬运修改。感谢蘭的分享。



7.添加了NVME SM951 SSD驱动补丁  修复二次安装出现的不识别固态或者固态不显示了。
修改config配置文件   更新到了clover4077版本



